import React from 'react';
import { Modal, Button } from 'react-bootstrap';

function InfoModal(props) {
    return (
        <Modal {...props}>
            <Modal.Header closeButton>
                <Modal.Title>More Information</Modal.Title>
            </Modal.Header>
            <Modal.Body>With Privnote, you can send notes that will self-destruct after being read. Simply write your note below, encrypt it, and receive a secure link. Send this link to the intended recipient, and once they read the note, it will automatically self-destruct. Additionally, by clicking the options button, you can customize your note by specifying a manual password for encryption, setting an expiration date, and receiving notifications when the note is destroyed.</Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={props.onHide}>
                    Close
                </Button>
            </Modal.Footer>
        </Modal>
    );
}

export default InfoModal;
