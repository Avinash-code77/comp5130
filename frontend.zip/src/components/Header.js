import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import InfoModal from './InfoModal'; // Import the InfoModal component


function Header() {
    const [userName, setUserName] = useState(null);
    const [showModal, setShowModal] = useState(false); // State to control modal visibility

    const navigate = useNavigate();

    // Get the user name from local storage if available
    useEffect(() => {
        const token = localStorage.getItem('authToken');
        if (token) {
            // Assuming the JWT contains user info and is decoded here
            const userInfo = JSON.parse(atob(token.split('.')[1])); // Decode the JWT
            setUserName(userInfo.email); // You can change this to userInfo.name if you save it in JWT
        }
    }, []);

    const handleLogout = () => {
        // Remove token from local storage
        localStorage.removeItem('authToken');
        setUserName(null);
        navigate('/login'); // Redirect to login page after logout
    };

    return (
        <div className="nav1">
            <div className="menu-wrap">
                <Link to="/">
                    <div className="logo">PrivaText</div>
                </Link>
                <div className="menu h-xs">
                    <Link to="/">
                        <div className="menu-item active">Create Message</div>
                    </Link>
                    {userName ? (
                        <>
                            <span className="menu-item">Hello, {userName}</span>
                            <button className="btn btn-outline-light" onClick={handleLogout}>Logout</button>
                        </>
                    ) : (
                        <>
                            <Link to="/login" className="menu-item">Login</Link>
                            <Link to="/register" className="menu-item">Register</Link>
                        </>
                    )}
                </div>
                <div className="right-menu">
                    <div className="cart-btn" onClick={() => setShowModal(true)}>
                        <i className='bx bx-question-mark'></i>
                    </div>
                </div>

                <InfoModal show={showModal} onHide={() => setShowModal(false)}/>

            </div>
        </div>
    );
}

export default Header;
