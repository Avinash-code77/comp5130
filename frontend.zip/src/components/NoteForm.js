import React, { useState } from 'react';
import axios from 'axios';

function NoteForm() {
    const [note, setNote] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [email, setEmail] = useState('');
    const [reference, setReference] = useState('');
    const [selfDestructOption, setSelfDestructOption] = useState('after_reading');
    const [confirmationCheck, setConfirmationCheck] = useState(false);
    const [optionsVisible, setOptionsVisible] = useState(true);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [shortUrl, setShortUrl] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (password && password !== confirmPassword) {
            alert('Passwords do not match!');
            return;
        }

        const noteData = {
            note,
            password,
            email,
            reference,
            selfDestructOption,
            confirmationCheck,
        };

        try {
            setLoading(true);
            setError('');
            const response = await axios.post('http://localhost:5000/api/notes', noteData);
            setShortUrl(response.data.shortUrl);
            alert('Note created successfully! Short URL: ' + response.data.shortUrl);

            // Reset form
            setNote('');
            setPassword('');
            setConfirmPassword('');
            setEmail('');
            setReference('');
            setSelfDestructOption('after_reading');
            setConfirmationCheck(false);
        } catch (error) {
            console.error('Error creating note:', error);
            setError('Failed to create note. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    const handleToggleOptions = () => {
        setOptionsVisible(!optionsVisible);
    };

    return (
        <section
            className="bg-img bg-img-fixed"
            style={{ backgroundImage: 'url(assets/katherine-chase-4MMK78S7eyk-unsplash.jpg)' }}
        >
            <div className="container">
                <div className="food-menu">
                    <h4 className="align-items-center">
                        <span className="primary-color">Create New Note</span>
                    </h4>
                    {error && <div className="alert alert-danger">{error}</div>}
                    {shortUrl && <div className="alert alert-success">Short URL: {shortUrl}</div>}
                    <form onSubmit={handleSubmit}>
                        {/* Note Input */}
                        <div className="mb-3">
                            <label htmlFor="your_summernote" className="form-label">
                                Write your note here...
                            </label>
                            <textarea
                                className="form-control"
                                id="your_summernote"
                                rows="10"
                                placeholder="Write your note here..."
                                value={note}
                                onChange={(e) => setNote(e.target.value)}
                                required
                            ></textarea>
                        </div>

                        {optionsVisible && (
                            <>
                                {/* Note Self-Destruct Options */}
                                <div className="mb-3">
                                    <label htmlFor="selfDestruct" className="form-label">
                                        Note self-destructs
                                    </label>
                                    <select
                                        className="form-select"
                                        id="selfDestruct"
                                        value={selfDestructOption}
                                        onChange={(e) => setSelfDestructOption(e.target.value)}
                                    >
                                        <option value="after_reading">after reading it</option>
                                        <option value="after_1_hour">after 1 hour</option>
                                        <option value="after_12_hours">after 12 hours</option>
                                        <option value="after_24_hours">after 24 hours</option>
                                    </select>
                                    <div className="form-check mt-2">
                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            id="confirmDestruction"
                                            checked={confirmationCheck}
                                            onChange={(e) => setConfirmationCheck(e.target.checked)}
                                        />
                                        <label className="form-check-label" htmlFor="confirmDestruction">
                                            Do not ask for confirmation before showing and destroying the note.
                                        </label>
                                    </div>
                                </div>

                                {/* Manual Password */}
                                <div className="row mb-3">
                                    <div className="col-md-6">
                                        <label htmlFor="password" className="form-label">
                                            Enter a custom password to encrypt the note
                                        </label>
                                        <input
                                            type="password"
                                            className="form-control"
                                            id="password"
                                            placeholder="Enter password"
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                        />
                                    </div>
                                    <div className="col-md-6">
                                        <label htmlFor="confirmPassword" className="form-label">
                                            Confirm password
                                        </label>
                                        <input
                                            type="password"
                                            className="form-control"
                                            id="confirmPassword"
                                            placeholder="Confirm password"
                                            value={confirmPassword}
                                            onChange={(e) => setConfirmPassword(e.target.value)}
                                        />
                                    </div>
                                </div>

                                {/* Destruction Notification */}
                                <div className="row mb-3">
                                    <div className="col-md-6">
                                        <label htmlFor="notificationEmail" className="form-label">
                                            E-mail to notify when note is destroyed
                                        </label>
                                        <input
                                            type="email"
                                            className="form-control"
                                            id="notificationEmail"
                                            placeholder="Enter email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                        />
                                    </div>
                                    <div className="col-md-6">
                                        <label htmlFor="referenceName" className="form-label">
                                            Reference name for the note (optional)
                                        </label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="referenceName"
                                            placeholder="Enter reference name"
                                            value={reference}
                                            onChange={(e) => setReference(e.target.value)}
                                        />
                                    </div>
                                </div>
                            </>
                        )}

                        {/* Buttons */}
                        <div className="d-flex justify-content-between">
                            <button type="submit" className="btn btn-danger" disabled={loading}>
                                {loading ? 'Saving...' : 'Create note'}
                            </button>
                            <button type="button" className="btn btn-success" onClick={handleToggleOptions}>
                                {optionsVisible ? 'Disable options' : 'Show options'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    );
}

export default NoteForm;
