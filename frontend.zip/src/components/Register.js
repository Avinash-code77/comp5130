import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Register() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleRegister = async (e) => {
        e.preventDefault();
        if (password !== confirmPassword) {
            setError("Passwords do not match!");
            return;
        }

        try {
            const res = await axios.post('http://localhost:5000/register', { name, email, password });

            localStorage.setItem('token', res.data.token);

            alert('Registration successful! You can now log in.');
            navigate('/login');
        } catch (err) {
            setError('Registration failed. Please try again.');
        }
    };

    return (
        <section className="bg-img bg-img-fixed" id="register-section"
                 style={{ backgroundImage: "url(assets/katherine-chase-4MMK78S7eyk-unsplash.jpg)" }}>
            <div className="container">
                <div className="food-menu">
                    <h4 className="align-items-center text-center mb-4">
                        <span className="primary-color">Create an Account</span>
                    </h4>
                    <form onSubmit={handleRegister}>
                        {error && <div className="alert alert-danger">{error}</div>}

                        <div className="row mb-3">
                            <div className="col-md-6">
                                <label className="form-label">Enter Your Name</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter your name"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">Enter Your Email</label>
                                <input
                                    type="email"
                                    className="form-control"
                                    placeholder="Enter your email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                            </div>
                        </div>

                        <div className="row mb-3">
                            <div className="col-md-6">
                                <label className="form-label">Enter Strong Password</label>
                                <input
                                    type="password"
                                    className="form-control"
                                    placeholder="Create a password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">Confirm Password</label>
                                <input
                                    type="password"
                                    className="form-control"
                                    placeholder="Confirm your password"
                                    value={confirmPassword}
                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                    required
                                />
                            </div>
                        </div>

                        <div className="d-flex align-items-center ">
                            <button type="submit" className="btn btn-danger">Register</button>
                        </div>

                        <p className="text-center mt-3">
                            Already have an account? <a href="/login" className="text-primary">Login here</a>
                        </p>
                    </form>
                </div>
            </div>
        </section>
    );
}

export default Register;
