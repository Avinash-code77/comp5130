import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            const res = await axios.post('http://localhost:5000/login', { email, password });

            // Assuming the response contains the JWT token
            const { token } = res.data;

            // Save the JWT token to local storage
            localStorage.setItem('authToken', token);

            // Redirect to a protected route (e.g., dashboard)
            alert('Login successful!');
            navigate('/dashboard');
        } catch (err) {
            // Handle login errors (wrong email/password, etc.)
            setError('Login failed. Please check your credentials.');
        }
    };

    return (
        <section className="bg-img bg-img-fixed" id="login-section"
                 style={{ backgroundImage: "url(assets/katherine-chase-4MMK78S7eyk-unsplash.jpg)" }}>
            <div className="container">
                <div className="food-menu">
                    <h4 className="align-items-center text-center mb-4">
                        <span className="primary-color">Login to Your Account</span>
                    </h4>
                    <form onSubmit={handleLogin}>
                        {error && <div className="alert alert-danger">{error}</div>}

                        <div className="mb-3">
                            <label htmlFor="loginEmail" className="form-label">Email</label>
                            <input
                                type="email"
                                className="form-control"
                                id="loginEmail"
                                placeholder="Enter your email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>

                        <div className="mb-3">
                            <label htmlFor="loginPassword" className="form-label">Password</label>
                            <input
                                type="password"
                                className="form-control"
                                id="loginPassword"
                                placeholder="Enter your password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                        </div>

                        <div className="d-flex justify-content-between">
                            <button type="submit" className="btn btn-danger">Login</button>
                        </div>

                        <p className="text-center mt-3">
                            Don't have an account? <a href="/register" className="text-primary">Register here</a>
                        </p>
                    </form>
                </div>
            </div>
        </section>
    );
}

export default Login;
