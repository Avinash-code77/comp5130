import React from 'react';
import { Link } from 'react-router-dom';

function Dashboard() {
    return (
        <div className="container-fluid">
            <div className="row">
                <nav className="col-md-2 d-none d-md-block bg-light sidebar">
                    <div className="sidebar-sticky">
                        <h5 className="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                            <span>Dashboard</span>
                        </h5>
                        <ul className="nav flex-column">
                            <li className="nav-item">
                                <Link className="nav-link active" to="/">
                                    Create Message
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/messages">
                                    View Messages
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/profile">
                                    Profile
                                </Link>
                            </li>

                            <li className="nav-item">
                                <Link className="nav-link" to="/logout">
                                    Logout
                                </Link>
                            </li>
                        </ul>
                    </div>
                </nav>

            </div>
        </div>
    );
}

export default Dashboard;
