// src/components/NoteReader.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button, Form } from 'react-bootstrap';
import CryptoJS from 'crypto-js';


const NoteReader = () => {
    const { id } = useParams(); // Get the note ID from the URL
    const navigate = useNavigate();
    const [note, setNote] = useState(null);
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [isDeleted, setIsDeleted] = useState(false);

    useEffect(() => {
        // Fetch the note using the provided ID
        const fetchNote = async () => {
            try {
                const response = await axios.get(`/api/notes/${id}`);
                setNote(response.data);
            } catch (err) {
                console.error('Error fetching note:', err);
                setError('Note not found or could not be retrieved.');
            }
        };

        fetchNote();
    }, [id]);

    const handleDelete = async () => {
        try {
            await axios.delete(`/api/notes/${id}`);
            setIsDeleted(true);
            setError('Note has been deleted successfully.');
            // Optionally navigate back to the dashboard or home page
            // navigate('/dashboard');
        } catch (err) {
            console.error('Error deleting note:', err);
            setError('Error deleting note.');
        }
    };

    const handleDecrypt = () => {
        if (!note) return;

        const { encryptedNote, password: storedPassword } = note;

        // Decrypt the note
        const decryptedNote = CryptoJS.AES.decrypt(encryptedNote, password).toString(CryptoJS.enc.Utf8);

        if (decryptedNote) {
            setNote((prevNote) => ({ ...prevNote, decryptedNote }));
        } else {
            setError('Incorrect password. Please try again.');
        }
    };

    if (isDeleted) {
        return <div>Your note has been deleted.</div>;
    }

    return (
        <div className="container mt-4">
            {error && <div className="alert alert-danger">{error}</div>}
            {note ? (
                <div>
                    <h2>Note Details</h2>
                    <p><strong>Reference:</strong> {note.reference || 'N/A'}</p>
                    <p><strong>Email:</strong> {note.email || 'N/A'}</p>
                    {note.encryptedNote ? (
                        <div>
                            <p><strong>Encrypted Note:</strong></p>
                            <p>{note.decryptedNote || 'Note is encrypted. Please enter password to view.'}</p>
                            <Form>
                                <Form.Group controlId="formBasicPassword">
                                    <Form.Label>Enter Password</Form.Label>
                                    <Form.Control
                                        type="password"
                                        placeholder="Password"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                </Form.Group>
                                <Button variant="primary" onClick={handleDecrypt}>
                                    Decrypt Note
                                </Button>
                            </Form>
                        </div>
                    ) : (
                        <div>
                            <h4>Note:</h4>
                            <p>{note.encryptedNote}</p>
                        </div>
                    )}
                    <Button variant="danger" onClick={handleDelete}>
                        Delete Note
                    </Button>
                </div>
            ) : (
                <p>Loading note...</p>
            )}
        </div>
    );
};

export default NoteReader;
