import React from 'react';

function FooterSection() {
    return (
        <section
            className="footer bg-img"
            style={{
                backgroundImage: `url(${process.env.PUBLIC_URL}/assets/nordwood-themes-pYWrdKO5ksI-unsplash.jpg)`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                padding: '50px 0',
            }}
        >
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-10 col-xs-12">
                        <h1 >Private Note</h1>
                        <br />
                        <p className="text-white">
                            Have you ever wanted to send confidential information within your work
                            environment, to family or friends, but were afraid to do so over the
                            internet, because some malicious hacker could be spying on you?
                        </p>
                        <p className="text-white">
                            Privnote is a free web-based service that allows you to send top secret
                            notes over the internet. It's fast, easy, and requires no password or
                            user registration at all.
                        </p>
                        <p className="text-white">
                            Just write your note, and you'll get a link. Then you copy and paste
                            that link into an email (or instant message) that you send to the person
                            who you want to read the note. When that person clicks the link for the
                            first time, they will see the note in their browser and the note will
                            automatically self-destruct; which means no one (even that very same
                            person) can read the note again. The link won't work anymore.
                        </p>
                        <br />
                    </div>
                </div>
            </div>
        </section>
    );
}

export default FooterSection;
